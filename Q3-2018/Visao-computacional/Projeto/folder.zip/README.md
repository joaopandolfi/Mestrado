# Projeto - Visão Computacional Q3.2018

Projeto desenvolvido durante a disciplina de visão computacional

## Requerimentos
* Versão do python: *Python3*
```
tensorflow
keras
scikit-image
Pillow
Keras
numpy
pandas
cv2
sklearn
```

## Executar
### Pre processamento
* Editar o fim do arquivo de
```
#PreProcess()

Train()
```
* Para
```
PreProcess()

#Train()
```

### Treinamento 
* O fim do arquivo tem que estar da seguinte forma:
```
#PreProcess()

Train()
```

### CLI
```
python3 main.py
```

# Author
Joáo Carlos Pandolfi Santana